package modelo;

public class Estagiario {
	
	private int id;
	private String cpf;
	private String nome;
	private String sexo;
	private String data_nascimento;
	private String telefoneCelular;
	private String telefoneCasa;
	private String cep;
	private String endereco;
	private String bairro;
	private String cidade;
	private String dataIngresso;
	private String codigo;
	private String idTermo;
	
	public Estagiario(int id, String cpf, String nome, String sexo, String data_nascimento, String telefoneCelular,
			String telefoneCasa, String cep, String endereco, String bairro, String cidade, String dataIngresso,
			String codigo, String idTermo) {
		super();
		this.id = id;
		this.cpf = cpf;
		this.nome = nome;
		this.sexo = sexo;
		this.data_nascimento = data_nascimento;
		this.telefoneCelular = telefoneCelular;
		this.telefoneCasa = telefoneCasa;
		this.cep = cep;
		this.endereco = endereco;
		this.bairro = bairro;
		this.cidade = cidade;
		this.dataIngresso = dataIngresso;
		this.codigo = codigo;
		this.idTermo = idTermo;
	}
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getSexo() {
		return sexo;
	}
	public void setSexo(String sexo) {
		this.sexo = sexo;
	}
	public String getData_nascimento() {
		return data_nascimento;
	}
	public void setData_nascimento(String data_nascimento) {
		this.data_nascimento = data_nascimento;
	}
	public String getTelefoneCelular() {
		return telefoneCelular;
	}
	public void setTelefoneCelular(String telefoneCelular) {
		this.telefoneCelular = telefoneCelular;
	}
	public String getTelefoneCasa() {
		return telefoneCasa;
	}
	public void setTelefoneCasa(String telefoneCasa) {
		this.telefoneCasa = telefoneCasa;
	}
	public String getCep() {
		return cep;
	}
	public void setCep(String cep) {
		this.cep = cep;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public String getBairro() {
		return bairro;
	}
	public void setBairro(String bairro) {
		this.bairro = bairro;
	}
	public String getCidade() {
		return cidade;
	}
	public void setCidade(String cidade) {
		this.cidade = cidade;
	}
	public String getDataIngresso() {
		return dataIngresso;
	}
	public void setDataIngresso(String dataIngresso) {
		this.dataIngresso = dataIngresso;
	}
	public String getCodigo() {
		return codigo;
	}
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	public String getIdTermo() {
		return idTermo;
	}
	public void setIdTermo(String idTermo) {
		this.idTermo = idTermo;
	}

}
