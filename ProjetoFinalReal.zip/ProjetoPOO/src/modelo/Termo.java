package modelo;

public class Termo {
	
	private int idTermo;
	private String inicioEstagio;
	private String fimEstagio;
	private String chDiaria;
	private String chSemanal;
	private String areaEstagio;
	private String horaInicio;
	private String horaFim;
	private String principaisAtividades;
	private String valorBolsa;
	private String beneficios;
	private String cnpj;
	private String cpf;
	private String nomeAluno;
	private String curso;
	private String orientador;
	private String universidade;
	private String representanteUniversidade;
	private String razaoSocial;
	private String representanteEmpresa;
	private String infosComplementares;



	


	public Termo(int idTermo, String inicioEstagio, String fimEstagio, String chDiaria, String chSemanal,
			String areaEstagio, String horaInicio, String horaFim, String principaisAtividades, String valorBolsa,
			String beneficios, String cnpj, String cpf, String nomeAluno, String curso, String orientador,
			String universidade, String representanteUniversidade, String razaoSocial, String representanteEmpresa, String infosComplementares) {
		super();
		this.idTermo = idTermo;
		this.inicioEstagio = inicioEstagio;
		this.fimEstagio = fimEstagio;
		this.chDiaria = chDiaria;
		this.chSemanal = chSemanal;
		this.areaEstagio = areaEstagio;
		this.horaInicio = horaInicio;
		this.horaFim = horaFim;
		this.principaisAtividades = principaisAtividades;
		this.valorBolsa = valorBolsa;
		this.beneficios = beneficios;
		this.cnpj = cnpj;
		this.cpf = cpf;
		this.nomeAluno = nomeAluno;
		this.curso = curso;
		this.orientador = orientador;
		this.universidade = universidade;
		this.representanteUniversidade = representanteUniversidade;
		this.razaoSocial = razaoSocial;
		this.representanteEmpresa = representanteEmpresa;
		this.infosComplementares = infosComplementares;
	}


	public int getIdTermo() {
		return idTermo;
	}


	public void setIdTermo(int idTermo) {
		this.idTermo = idTermo;
	}


	public String getInicioEstagio() {
		return inicioEstagio;
	}


	public void setInicioEstagio(String inicioEstagio) {
		this.inicioEstagio = inicioEstagio;
	}


	public String getFimEstagio() {
		return fimEstagio;
	}


	public void setFimEstagio(String fimEstagio) {
		this.fimEstagio = fimEstagio;
	}


	public String getChDiaria() {
		return chDiaria;
	}


	public void setChDiaria(String chDiaria) {
		this.chDiaria = chDiaria;
	}


	public String getChSemanal() {
		return chSemanal;
	}


	public void setChSemanal(String chSemanal) {
		this.chSemanal = chSemanal;
	}


	public String getAreaEstagio() {
		return areaEstagio;
	}


	public void setAreaEstagio(String areaEstagio) {
		this.areaEstagio = areaEstagio;
	}


	public String getHoraInicio() {
		return horaInicio;
	}


	public void setHoraInicio(String horaInicio) {
		this.horaInicio = horaInicio;
	}


	public String getHoraFim() {
		return horaFim;
	}


	public void setHoraFim(String horaFim) {
		this.horaFim = horaFim;
	}


	public String getPrincipaisAtividades() {
		return principaisAtividades;
	}


	public void setPrincipaisAtividades(String principaisAtividades) {
		this.principaisAtividades = principaisAtividades;
	}


	public String getValorBolsa() {
		return valorBolsa;
	}


	public void setValorBolsa(String valorBolsa) {
		this.valorBolsa = valorBolsa;
	}


	public String getBeneficios() {
		return beneficios;
	}


	public void setBeneficios(String beneficios) {
		this.beneficios = beneficios;
	}


	public String getCnpj() {
		return cnpj;
	}


	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}
	
	public String getCpf() {
		return cpf;
	}


	public void setCpf(String cpf) {
		this.cpf = cpf;
	}


	public String getNomeAluno() {
		return nomeAluno;
	}


	public void setNomeAluno(String nomeAluno) {
		this.nomeAluno = nomeAluno;
	}


	public String getCurso() {
		return curso;
	}


	public void setCurso(String curso) {
		this.curso = curso;
	}


	public String getOrientador() {
		return orientador;
	}


	public void setOrientador(String orientador) {
		this.orientador = orientador;
	}


	public String getUniversidade() {
		return universidade;
	}


	public void setUniversidade(String universidade) {
		this.universidade = universidade;
	}


	public String getRepresentanteUniversidade() {
		return representanteUniversidade;
	}


	public void setRepresentanteUniversidade(String representanteUniversidade) {
		this.representanteUniversidade = representanteUniversidade;
	}


	public String getRazaoSocial() {
		return razaoSocial;
	}


	public void setRazaoSocial(String razaoSocial) {
		this.razaoSocial = razaoSocial;
	}


	public String getRepresentanteEmpresa() {
		return representanteEmpresa;
	}


	public void setRepresentanteEmpresa(String representanteEmpresa) {
		this.representanteEmpresa = representanteEmpresa;
	}


	public String getInfosComplementares() {
		return infosComplementares;
	}


	public void setInfosComplementares(String infosComplementares) {
		this.infosComplementares = infosComplementares;
	}
	
	

}
