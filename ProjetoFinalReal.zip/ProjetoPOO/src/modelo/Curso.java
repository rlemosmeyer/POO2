package modelo;

public class Curso {

	private int codigo;
	private String nome;
	private String telefoneCoordenacao;
	private String representanteCoordenacao;
	private String cargoRepresentante;
	private int idUniversidade;
	
	
	public Curso(int codigo, String nome, String telefoneCoordenacao, String representanteCoordenacao,
			String cargoRepresentante, int idUniversidade) {
		super();
		this.codigo = codigo;
		this.nome = nome;
		this.telefoneCoordenacao = telefoneCoordenacao;
		this.representanteCoordenacao = representanteCoordenacao;
		this.cargoRepresentante = cargoRepresentante;
		this.idUniversidade = idUniversidade;
	}


	public int getCodigo() {
		return codigo;
	}


	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}


	public String getNome() {
		return nome;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}


	public String getTelefoneCoordenacao() {
		return telefoneCoordenacao;
	}


	public void setTelefoneCoordenacao(String telefoneCoordenacao) {
		this.telefoneCoordenacao = telefoneCoordenacao;
	}


	public String getRepresentanteCoordenacao() {
		return representanteCoordenacao;
	}


	public void setRepresentanteCoordenacao(String representanteCoordenacao) {
		this.representanteCoordenacao = representanteCoordenacao;
	}


	public String getCargoRepresentante() {
		return cargoRepresentante;
	}


	public void setCargoRepresentante(String cargoRepresentante) {
		this.cargoRepresentante = cargoRepresentante;
	}


	public int getIdUniversidade() {
		return idUniversidade;
	}


	public void setIdUniversidade(int idUniversidade) {
		this.idUniversidade = idUniversidade;
	}
	
	
	
}
