package modelo;

public class EmpresaConcedente {
	
	private int idEmpresaConcedente;
	private String cnpj;
	private String razaoSocial;
	private String nomeRepresentante;
	private String infosComplementares;
	private String telefone;
	private String cargoRepresentante;
	private String cep;
	private String bairro;
	private String endereco;
	private String cidade;
	private String estado;
	
	
	public EmpresaConcedente(int idEmpresaConcedente, String cnpj, String razaoSocial, String nomeRepresentante,
			String infosComplementares, String telefone, String cargoRepresentante, String cep, String bairro,
			String endereco, String cidade, String estado) {
		super();
		this.idEmpresaConcedente = idEmpresaConcedente;
		this.cnpj = cnpj;
		this.razaoSocial = razaoSocial;
		this.nomeRepresentante = nomeRepresentante;
		this.infosComplementares = infosComplementares;
		this.telefone = telefone;
		this.cargoRepresentante = cargoRepresentante;
		this.cep = cep;
		this.bairro = bairro;
		this.endereco = endereco;
		this.cidade = cidade;
		this.estado = estado;
	}


	public int getIdEmpresaConcedente() {
		return idEmpresaConcedente;
	}


	public void setIdEmpresaConcedente(int idEmpresaConcedente) {
		this.idEmpresaConcedente = idEmpresaConcedente;
	}


	public String getCnpj() {
		return cnpj;
	}


	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}


	public String getRazaoSocial() {
		return razaoSocial;
	}


	public void setRazaoSocial(String razaoSocial) {
		this.razaoSocial = razaoSocial;
	}


	public String getNomeRepresentante() {
		return nomeRepresentante;
	}


	public void setNomeRepresentante(String nomeRepresentante) {
		this.nomeRepresentante = nomeRepresentante;
	}


	public String getInfosComplementares() {
		return infosComplementares;
	}


	public void setInfosComplementares(String infosComplementares) {
		this.infosComplementares = infosComplementares;
	}


	public String getTelefone() {
		return telefone;
	}


	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}


	public String getCargoRepresentante() {
		return cargoRepresentante;
	}


	public void setCargoRepresentante(String cargoRepresentante) {
		this.cargoRepresentante = cargoRepresentante;
	}


	public String getCep() {
		return cep;
	}


	public void setCep(String cep) {
		this.cep = cep;
	}


	public String getBairro() {
		return bairro;
	}


	public void setBairro(String bairro) {
		this.bairro = bairro;
	}


	public String getEndereco() {
		return endereco;
	}


	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}


	public String getCidade() {
		return cidade;
	}


	public void setCidade(String cidade) {
		this.cidade = cidade;
	}


	public String getEstado() {
		return estado;
	}


	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	
	
	
	

}
