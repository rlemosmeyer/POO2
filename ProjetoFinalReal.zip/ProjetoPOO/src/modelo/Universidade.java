package modelo;

public class Universidade {
	
	private int id;
	private String nomeUniversidade;
	private String telefoneGeral;
	private String nomeRepresentante;
	private String cargoRepresentante;
	private String cnpj;
	private String cep;
	private String endereco;
	private String bairro;
	private String cidade;
	private String estado;
	
	public Universidade(int id, String nomeUniversidade, String telefoneGeral, String nomeRepresentante,
			String cargoRepresentante, String cnpj, String cep, String endereco, String bairro, String cidade,
			String estado) {
		super();
		this.id = id;
		this.nomeUniversidade = nomeUniversidade;
		this.telefoneGeral = telefoneGeral;
		this.nomeRepresentante = nomeRepresentante;
		this.cargoRepresentante = cargoRepresentante;
		this.cnpj = cnpj;
		this.cep = cep;
		this.endereco = endereco;
		this.bairro = bairro;
		this.cidade = cidade;
		this.estado = estado;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNomeUniversidade() {
		return nomeUniversidade;
	}

	public void setNomeUniversidade(String nomeUniversidade) {
		this.nomeUniversidade = nomeUniversidade;
	}

	public String getTelefoneGeral() {
		return telefoneGeral;
	}

	public void setTelefoneGeral(String telefoneGeral) {
		this.telefoneGeral = telefoneGeral;
	}

	public String getNomeRepresentante() {
		return nomeRepresentante;
	}

	public void setNomeRepresentante(String nomeRepresentante) {
		this.nomeRepresentante = nomeRepresentante;
	}

	public String getCargoRepresentante() {
		return cargoRepresentante;
	}

	public void setCargoRepresentante(String cargoRepresentante) {
		this.cargoRepresentante = cargoRepresentante;
	}

	public String getCnpj() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	
	
	
	
	
	
	
	

}
