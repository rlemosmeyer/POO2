package dao;

public class UniversidadeDAO {

}
