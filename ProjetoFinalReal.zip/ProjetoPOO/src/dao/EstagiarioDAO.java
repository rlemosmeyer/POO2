package dao;

public class EstagiarioDAO {

}
