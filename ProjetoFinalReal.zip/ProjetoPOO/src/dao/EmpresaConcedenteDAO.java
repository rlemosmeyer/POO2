package dao;

public class EmpresaConcedenteDAO {

}
