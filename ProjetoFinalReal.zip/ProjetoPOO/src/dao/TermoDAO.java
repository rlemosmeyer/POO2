package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import modelo.Estagiario;
import modelo.Termo;

public class TermoDAO {
	
	private Connection con = null;
	
	public boolean salvaTermo(Termo t) {
		boolean ret = false;

		ConexaoMYSQL.abrirConexao();
		con = ConexaoMYSQL.getCon();

		String sql = "INSERT INTO Termos values (null,?,?,?,?,?,?,?,?,?,?,?,?,?)";

		PreparedStatement prepS;

		try {
			prepS = con.prepareStatement(sql);
			prepS.setString(1, t.getInicioEstagio());
			prepS.setString(2, t.getFimEstagio());
			prepS.setString(3, t.getChDiaria());
			prepS.setString(4, t.getChSemanal());
			prepS.setString(5, t.getAreaEstagio());
			prepS.setString(6, t.getHoraInicio());
			prepS.setString(7, t.getHoraFim());
			prepS.setString(8, t.getPrincipaisAtividades());
			prepS.setString(9, t.getValorBolsa());
			prepS.setString(10, t.getBeneficios());
			prepS.setString(11, t.getCnpj());
			prepS.setString(12, t.getCpf());
			prepS.setString(13, t.getInfosComplementares());
			
			int res = prepS.executeUpdate();

			if (res == 1) {
				ret = true;
			}
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ret;
	}
	
	public boolean verificaTermo(int id) {
		ConexaoMYSQL.abrirConexao();
		con = ConexaoMYSQL.getCon();
		String sql = "select * from Termos where idTermo = ?";
		
		PreparedStatement prepS;
		
		try {
			prepS = con.prepareStatement(sql);
			prepS.setInt(1, id);
			
			ResultSet res = prepS.executeQuery();
			while (res.next()) {
				return true;
			}				
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return false;
	}
	
	public Termo consultaTermo(int idTermo) {
		ConexaoMYSQL.abrirConexao();
		con = ConexaoMYSQL.getCon();
		String sql = "SELECT t.idTermo, t.inicioEstagio, t.fimEstagio, t.chDiaria, t.chSemanal, t.horaInicio, t.horaFim, t.areaEstagio, t.principaisAtividades, t.valorBolsa, t.beneficios, e.cpf, e.nome, c.nome, c.representanteCoordenacao, u.nomeUniversidade, u.nomeRepresentante, ec.cnpj, ec.razaoSocial, ec.nomeRepresentante, t.infosComplementares FROM EmpresaConcedente AS ec INNER JOIN Termos AS t ON ec.cnpj = t.EmpresaConcedente_cnpj INNER JOIN Estagiario AS e ON e.cpf = t.Estagiario_cpf INNER JOIN Curso AS c ON c.codigo = e.Curso_codigo INNER JOIN Universidade AS u ON u.id = c.Universidade_id WHERE t.idTermo = ?";
		Termo t = new Termo(0, "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "");
		PreparedStatement prepS;
		
		try {
			prepS = con.prepareStatement(sql);
			prepS.setInt(1, idTermo);
			ResultSet res = prepS.executeQuery();
			while (res.next()) {
				t.setIdTermo(res.getInt(1));
				t.setInicioEstagio(res.getString(2));
				t.setFimEstagio(res.getString(3));
				t.setChDiaria(res.getString(4));
				t.setChSemanal(res.getString(5));
				t.setHoraInicio(res.getString(6));
				t.setHoraFim(res.getString(7));
				t.setAreaEstagio(res.getString(8));
				t.setPrincipaisAtividades(res.getString(9));
				t.setValorBolsa(res.getString(10));
				t.setBeneficios(res.getString(11));
				t.setCpf(res.getString(12));
				t.setNomeAluno(res.getString(13));
				t.setCurso(res.getString(14));
				t.setOrientador(res.getString(15));
				t.setUniversidade(res.getString(16));
				t.setRepresentanteUniversidade(res.getString(17));
				t.setCnpj(res.getString(18));
				t.setRazaoSocial(res.getString(19));
				t.setRepresentanteEmpresa(res.getString(20));
				t.setInfosComplementares(res.getString(21));
				return t;
			}
		} catch (SQLException e1) {

			e1.printStackTrace();
		}
		return t;
	}
	
	public boolean removeTermo(Termo t) {
		return true;
	}
	
	public boolean atualizaTermo(Termo t) {
		return true;
	}
	
	public boolean validaCpf(String cpf) {
		ConexaoMYSQL.abrirConexao();
		con = ConexaoMYSQL.getCon();
		String sql = "select * from Estagiario where cpf = ?";
		
		PreparedStatement prepS;
		
		try {
			prepS = con.prepareStatement(sql);
			prepS.setString(1, cpf);
			
			ResultSet res = prepS.executeQuery();
			while (res.next()) {
				return true;
			}				
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return false;
	}
	
	public String[] retornaEstagiario(String cpf) {
		ConexaoMYSQL.abrirConexao();
		con = ConexaoMYSQL.getCon();
		String sql = "SELECT e.nome, c.nome, c.representanteCoordenacao, u.nomeUniversidade, u.nomeRepresentante FROM Estagiario AS e INNER JOIN CURSO AS c ON c.codigo = e.Curso_codigo INNER JOIN Universidade AS u ON u.id = c.Universidade_id WHERE cpf = ?";
		
		String vet[] = new String[5];
		PreparedStatement prepS;
		
		try {
			prepS = con.prepareStatement(sql);
			prepS.setString(1, cpf);
			ResultSet res = prepS.executeQuery();
			while (res.next()) {
				vet[0] = res.getString(1);
				vet[1] = res.getString(2);
				vet[2] = res.getString(3);
				vet[3] = res.getString(4);
				vet[4] = res.getString(5);
				
				return vet;
			}
		} catch (SQLException e1) {

			e1.printStackTrace();
		}
		return vet;
	}
	
	public String[] retornaEmpresa(String cnpj) {
		ConexaoMYSQL.abrirConexao();
		con = ConexaoMYSQL.getCon();
		String sql = "SELECT razaoSocial, nomeRepresentante FROM EmpresaConcedente WHERE cnpj = ?";
		
		String vet[] = new String[2];
		PreparedStatement prepS;
		
		try {
			prepS = con.prepareStatement(sql);
			prepS.setString(1, cnpj);
			ResultSet res = prepS.executeQuery();
			while (res.next()) {
				vet[0] = res.getString(1);
				vet[1] = res.getString(2);
				System.out.println(res.getString(1) + res.getString(2));
				return vet;
			}	
		} catch (SQLException e1) {

			e1.printStackTrace();
		}
		return vet;
	}
	
	public boolean validaCnpj(String cnpj) {
		ConexaoMYSQL.abrirConexao();
		con = ConexaoMYSQL.getCon();
		String sql = "select * from EmpresaConcedente where cnpj = ?";
		
		PreparedStatement prepS;
		
		try {
			prepS = con.prepareStatement(sql);
			prepS.setString(1, cnpj);
			
			ResultSet res = prepS.executeQuery();
			while (res.next()) {
				System.out.println(res.getString(1));
				return true;
			}				
			con.close();
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return false;
	}
	

}
