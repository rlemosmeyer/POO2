 package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexaoMYSQL {

	private static Connection con;
	private static String status;

	public ConexaoMYSQL() {}

	public static void abrirConexao() {
		
		String serverName = "localhost";
		String database = "poo";
		String url = "jdbc:mysql://" + serverName + ":3306/" + database + "?userTimezone=true&serverTimezone=UTC";
		String userName = "root"; 
		String password = "password"; 

		try {
			con = DriverManager.getConnection(url, userName, password);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		if (con != null) {
			status = "STATUS-----> Conectado com sucesso!";
		} else {
			status = "STATUS-----> Não foi possível realizar a conexão";
		}

	}

	public static boolean fecharConexao() {
		try {
			con.close();
			System.out.println("Conexao encerrada!");
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}

	}
	
	public static Connection getCon() {
		return con;
	}

	public static void setCon(Connection con) {
		ConexaoMYSQL.con = con;
	}

}
