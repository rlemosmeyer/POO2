package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import modelo.Usuario;

public class UsuarioDAO {
	
	private Connection con = null;

	public UsuarioDAO() {
		
	}
	
	public boolean login(Usuario u) {
		
		ConexaoMYSQL.abrirConexao();
		con = ConexaoMYSQL.getCon();
		String sql = "select * from Usuario where usuario = ? and senha = ?";
		
		boolean ret = false;

		PreparedStatement prepS;
		
		try {
			prepS = con.prepareStatement(sql);
			prepS.setString(1, u.getUsuario());
			prepS.setString(2, u.getSenha());
			
			ResultSet res = prepS.executeQuery();
			while (res.next()) {
				return true;
			}				
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

}
