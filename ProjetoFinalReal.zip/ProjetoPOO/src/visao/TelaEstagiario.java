package visao;

import javax.swing.JPanel;
import net.miginfocom.swing.MigLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JRadioButton;

import java.awt.Image;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.ImageIcon;

public class TelaEstagiario extends JPanel {
	
	private JTextField textFieldCpf;
	private JTextField textFieldNome;
	private JTextField textFieldTelCel;
	private JTextField textFieldTelCasa;
	private JTextField textFieldDataNasc;
	private JTextField textFieldCep;
	private JTextField textFieldEndereco;
	private JTextField textFieldBairro;
	private JTextField textFieldCidade;
	private JTextField textFieldCurso;
	private JTextField textFieldDataIngresso;
	private ButtonGroup Radio;
	private JRadioButton rdbtnMasculino;
	private JRadioButton rdbtnFeminino;
	private JButton btnCriar;
	private JButton btnConsultar;
	private JButton btnAtualizar;
	private JButton btnRemover;
	private JButton btnLimpar;


	/**
	 * Create the panel.
	 */
	public TelaEstagiario() {
		setLayout(new MigLayout("", "[grow]", "[][][][][][][][][][][][][]"));
		
		JLabel lblNewLabel = new JLabel("CPF");
		add(lblNewLabel, "flowx,cell 0 0,growx");
		
		textFieldCpf = new JTextField();
		add(textFieldCpf, "flowx,cell 0 1,growx");
		textFieldCpf.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Sexo");
		add(lblNewLabel_2, "flowx,cell 0 2,growx");
		
		rdbtnMasculino = new JRadioButton("Masculino");
		add(rdbtnMasculino, "flowx,cell 0 3");
		
		JLabel lblNewLabel_4 = new JLabel("Telefone (Celular)");
		add(lblNewLabel_4, "flowx,cell 0 4,growx");
		
		textFieldTelCel = new JTextField();
		add(textFieldTelCel, "flowx,cell 0 5,growx");
		textFieldTelCel.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Nome");
		add(lblNewLabel_1, "cell 0 0,growx");
		
		textFieldNome = new JTextField();
		add(textFieldNome, "cell 0 1,growx");
		textFieldNome.setColumns(10);
		
		rdbtnFeminino = new JRadioButton("Feminino");
		add(rdbtnFeminino, "cell 0 3,growx");
		
		JLabel lblNewLabel_3 = new JLabel("Data Nascimento");
		add(lblNewLabel_3, "cell 0 2,growx");
		
		textFieldDataNasc = new JTextField();
		add(textFieldDataNasc, "cell 0 3,growx");
		textFieldDataNasc.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("Telefone (Casa)");
		add(lblNewLabel_5, "cell 0 4,growx");
		
		textFieldTelCasa = new JTextField();
		add(textFieldTelCasa, "cell 0 5,growx");
		textFieldTelCasa.setColumns(10);
		
		JLabel lblNewLabel_6 = new JLabel("CEP");
		add(lblNewLabel_6, "flowx,cell 0 6,growx");
		
		textFieldCep = new JTextField();
		add(textFieldCep, "flowx,cell 0 7,growx");
		textFieldCep.setColumns(10);
		
		JLabel lblNewLabel_7 = new JLabel("Endere\u00E7o");
		add(lblNewLabel_7, "cell 0 6,growx");
		
		textFieldEndereco = new JTextField();
		add(textFieldEndereco, "cell 0 7,growx");
		textFieldEndereco.setColumns(10);
		
		JLabel lblNewLabel_8 = new JLabel("Bairro");
		add(lblNewLabel_8, "flowx,cell 0 8,growx");
		
		textFieldBairro = new JTextField();
		add(textFieldBairro, "flowx,cell 0 9,growx");
		textFieldBairro.setColumns(10);
		
		JLabel lblNewLabel_9 = new JLabel("Cidade");
		add(lblNewLabel_9, "cell 0 8,growx");
		
		JLabel lblNewLabel_10 = new JLabel("Curso");
		add(lblNewLabel_10, "flowx,cell 0 10,growx");
		
		JLabel lblNewLabel_11 = new JLabel("Data de Ingresso");
		add(lblNewLabel_11, "cell 0 10,growx");
		
		textFieldCidade = new JTextField();
		add(textFieldCidade, "cell 0 9,growx");
		textFieldCidade.setColumns(10);
		
		textFieldCurso = new JTextField();
		add(textFieldCurso, "flowx,cell 0 11,growx");
		textFieldCurso.setColumns(10);
		
		textFieldDataIngresso = new JTextField();
		add(textFieldDataIngresso, "cell 0 11,growx");
		textFieldDataIngresso.setColumns(10);
		
		btnCriar = new JButton("Criar");
		btnCriar.setIcon(new ImageIcon(new ImageIcon(this.getClass().getResource("/icones/icons8-plus-+-40.png")).getImage().getScaledInstance(24, 24, Image.SCALE_DEFAULT)));
		add(btnCriar, "flowx,cell 0 12,growx");
		
		btnConsultar = new JButton("Consultar");
		btnConsultar.setIcon(new ImageIcon(new ImageIcon(this.getClass().getResource("/icones/job-search__1_-removebg-preview.png")).getImage().getScaledInstance(24, 24, Image.SCALE_DEFAULT)));
		add(btnConsultar, "cell 0 12,growx");
		
		btnAtualizar = new JButton("Atualizar");
		btnAtualizar.setIcon(new ImageIcon(new ImageIcon(this.getClass().getResource("/icones/update-removebg-preview.png")).getImage().getScaledInstance(24, 24, Image.SCALE_DEFAULT)));
		add(btnAtualizar, "cell 0 12,growx");
		
		btnRemover = new JButton("Remover");
		btnRemover.setIcon(new ImageIcon(new ImageIcon(this.getClass().getResource("/icones/remover-usuario-removebg-preview.png")).getImage().getScaledInstance(24, 24, Image.SCALE_DEFAULT)));
		add(btnRemover, "cell 0 12,growx");
		
		btnLimpar = new JButton("Limpar");
		btnLimpar.setIcon(new ImageIcon(new ImageIcon(this.getClass().getResource("/icones/icons8-erase-40__1_-removebg-preview.png")).getImage().getScaledInstance(24, 24, Image.SCALE_DEFAULT)));
		add(btnLimpar, "cell 0 12,growx");

		Radio = new ButtonGroup();
		Radio.add(rdbtnMasculino);
		Radio.add(rdbtnFeminino);
	}


	public JTextField getTextFieldCpf() {
		return textFieldCpf;
	}


	public void setTextFieldCpf(JTextField textFieldCpf) {
		this.textFieldCpf = textFieldCpf;
	}


	public JTextField getTextFieldNome() {
		return textFieldNome;
	}


	public void setTextFieldNome(JTextField textFieldNome) {
		this.textFieldNome = textFieldNome;
	}


	public JTextField getTextFieldTelCel() {
		return textFieldTelCel;
	}


	public void setTextFieldTelCel(JTextField textFieldTelCel) {
		this.textFieldTelCel = textFieldTelCel;
	}


	public JTextField getTextFieldTelCasa() {
		return textFieldTelCasa;
	}


	public void setTextFieldTelCasa(JTextField textFieldTelCasa) {
		this.textFieldTelCasa = textFieldTelCasa;
	}


	public JTextField getTextFieldDataNasc() {
		return textFieldDataNasc;
	}


	public void setTextFieldDataNasc(JTextField textFieldDataNasc) {
		this.textFieldDataNasc = textFieldDataNasc;
	}


	public JTextField getTextFieldCep() {
		return textFieldCep;
	}


	public void setTextFieldCep(JTextField textFieldCep) {
		this.textFieldCep = textFieldCep;
	}


	public JTextField getTextFieldEndereco() {
		return textFieldEndereco;
	}


	public void setTextFieldEndereco(JTextField textFieldEndereco) {
		this.textFieldEndereco = textFieldEndereco;
	}


	public JTextField getTextFieldBairro() {
		return textFieldBairro;
	}


	public void setTextFieldBairro(JTextField textFieldBairro) {
		this.textFieldBairro = textFieldBairro;
	}


	public JTextField getTextFieldCidade() {
		return textFieldCidade;
	}


	public void setTextFieldCidade(JTextField textFieldCidade) {
		this.textFieldCidade = textFieldCidade;
	}


	public JTextField getTextFieldCurso() {
		return textFieldCurso;
	}


	public void setTextFieldCurso(JTextField textFieldCurso) {
		this.textFieldCurso = textFieldCurso;
	}


	public JTextField getTextFieldDataIngresso() {
		return textFieldDataIngresso;
	}


	public void setTextFieldDataIngresso(JTextField textFieldDataIngresso) {
		this.textFieldDataIngresso = textFieldDataIngresso;
	}


	public ButtonGroup getRadio() {
		return Radio;
	}


	public void setRadio(ButtonGroup radio) {
		Radio = radio;
	}


	public JRadioButton getRdbtnMasculino() {
		return rdbtnMasculino;
	}


	public void setRdbtnMasculino(JRadioButton rdbtnMasculino) {
		this.rdbtnMasculino = rdbtnMasculino;
	}


	public JRadioButton getRdbtnFeminino() {
		return rdbtnFeminino;
	}


	public void setRdbtnFeminino(JRadioButton rdbtnFeminino) {
		this.rdbtnFeminino = rdbtnFeminino;
	}


	public JButton getBtnCriar() {
		return btnCriar;
	}


	public void setBtnCriar(JButton btnCriar) {
		this.btnCriar = btnCriar;
	}


	public JButton getBtnConsultar() {
		return btnConsultar;
	}


	public void setBtnConsultar(JButton btnConsultar) {
		this.btnConsultar = btnConsultar;
	}


	public JButton getBtnAtualizar() {
		return btnAtualizar;
	}


	public void setBtnAtualizar(JButton btnAtualizar) {
		this.btnAtualizar = btnAtualizar;
	}


	public JButton getBtnRemover() {
		return btnRemover;
	}


	public void setBtnRemover(JButton btnRemover) {
		this.btnRemover = btnRemover;
	}


	public JButton getBtnLimpar() {
		return btnLimpar;
	}


	public void setBtnLimpar(JButton btnLimpar) {
		this.btnLimpar = btnLimpar;
	}
	
	

}
