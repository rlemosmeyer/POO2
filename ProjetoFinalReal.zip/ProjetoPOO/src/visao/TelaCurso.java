package visao;

import javax.swing.JPanel;
import net.miginfocom.swing.MigLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JButton;

import java.awt.Image;

import javax.swing.ImageIcon;

public class TelaCurso extends JPanel {
	private JTextField textFieldCodigo;
	private JTextField textFieldNomeCurso;
	private JTextField textFieldCargoRepCurso;
	private JTextField textFieldNomeUni;
	private JTextField textFieldRepCoord;
	private JTextField textFieldCnpj;
	private JTextField textFieldCep;
	private JTextField textFieldEndereco;
	private JTextField textFieldBairro;
	private JTextField textFieldCidade;
	private JTextField textFieldEstado;
	private JTextField textFieldRepUniv;
	private JTextField textFieldTelefoneUniv;
	private JTextField textFieldCargoRepUniv;
	private JTextField textFieldTelefoneCoord;
	private JButton btnCriar;
	private JButton btnConsultar;
	private JButton btnAtualizar;
	private JButton btnRemover;
	private JButton btnLimpar;

	/**
	 * Create the panel.
	 */
	public TelaCurso() {
		setLayout(new MigLayout("", "[grow]", "[][][][][][][][][][][][][][][][][]"));
		
		JLabel lblNewLabel = new JLabel("C\u00F3digo");
		add(lblNewLabel, "flowx,cell 0 0,growx");
		
		textFieldCodigo = new JTextField();
		add(textFieldCodigo, "flowx,cell 0 1,growx");
		textFieldCodigo.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Telefone da Coordena\u00E7\u00E3o");
		add(lblNewLabel_2, "flowx,cell 0 2,growx");
		
		JLabel lblNewLabel_4 = new JLabel("Cargo do Representante");
		add(lblNewLabel_4, "flowx,cell 0 4,growx");
		
		textFieldCargoRepCurso = new JTextField();
		add(textFieldCargoRepCurso, "flowx,cell 0 5,growx");
		textFieldCargoRepCurso.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Nome do Curso");
		add(lblNewLabel_1, "cell 0 0,growx");
		
		textFieldNomeCurso = new JTextField();
		add(textFieldNomeCurso, "cell 0 1,growx");
		textFieldNomeCurso.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Representante da Coordena\u00E7\u00E3o");
		add(lblNewLabel_3, "cell 0 2,growx");
		
		textFieldTelefoneCoord = new JTextField();
		add(textFieldTelefoneCoord, "flowx,cell 0 3,growx");
		textFieldTelefoneCoord.setColumns(10);
		
		textFieldRepCoord = new JTextField();
		add(textFieldRepCoord, "cell 0 3,growx");
		textFieldRepCoord.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("Nome da Universidade");
		add(lblNewLabel_5, "cell 0 4,growx");
		
		textFieldNomeUni = new JTextField();
		add(textFieldNomeUni, "cell 0 5,growx");
		textFieldNomeUni.setColumns(10);
		
		JLabel lblNewLabel_6 = new JLabel("CNPJ");
		add(lblNewLabel_6, "flowx,cell 0 6,growx");
		
		textFieldCnpj = new JTextField();
		add(textFieldCnpj, "flowx,cell 0 7,growx");
		textFieldCnpj.setColumns(10);
		
		JLabel lblNewLabel_7 = new JLabel("CEP");
		add(lblNewLabel_7, "cell 0 6,growx");
		
		textFieldCep = new JTextField();
		add(textFieldCep, "cell 0 7,growx");
		textFieldCep.setColumns(10);
		
		JLabel lblNewLabel_8 = new JLabel("Endere\u00E7o");
		add(lblNewLabel_8, "flowx,cell 0 8,growx");
		
		textFieldEndereco = new JTextField();
		add(textFieldEndereco, "flowx,cell 0 9,growx");
		textFieldEndereco.setColumns(10);
		
		JLabel lblNewLabel_9 = new JLabel("Bairro");
		add(lblNewLabel_9, "cell 0 8,growx");
		
		JLabel lblNewLabel_10 = new JLabel("Cidade");
		add(lblNewLabel_10, "flowx,cell 0 10,growx");
		
		JLabel lblNewLabel_11 = new JLabel("Estado");
		add(lblNewLabel_11, "cell 0 10,growx");
		
		textFieldBairro = new JTextField();
		add(textFieldBairro, "cell 0 9,growx");
		textFieldBairro.setColumns(10);
		
		textFieldCidade = new JTextField();
		add(textFieldCidade, "flowx,cell 0 11,growx");
		textFieldCidade.setColumns(10);
		
		textFieldEstado = new JTextField();
		add(textFieldEstado, "cell 0 11,growx");
		textFieldEstado.setColumns(10);
		
		JLabel lblNewLabel_12 = new JLabel("Telefone Geral da Universidade");
		add(lblNewLabel_12, "flowx,cell 0 12,growx");
		
		textFieldTelefoneUniv = new JTextField();
		add(textFieldTelefoneUniv, "cell 0 13,growx");
		textFieldTelefoneUniv.setColumns(10);
		
		textFieldRepUniv = new JTextField();
		add(textFieldRepUniv, "cell 0 13,growx");
		textFieldRepUniv.setColumns(10);
		
		JLabel lblNewLabel_14 = new JLabel("Cargo do Representante da Universidade");
		add(lblNewLabel_14, "cell 0 14");
		
		textFieldCargoRepUniv = new JTextField();
		add(textFieldCargoRepUniv, "cell 0 15,growx");
		textFieldCargoRepUniv.setColumns(10);
		
		btnCriar = new JButton("Criar");
		btnCriar.setIcon(new ImageIcon(new ImageIcon(this.getClass().getResource("/icones/icons8-plus-+-40.png")).getImage().getScaledInstance(24, 24, Image.SCALE_DEFAULT)));
		add(btnCriar, "flowx,cell 0 16,growx");
		
		btnConsultar = new JButton("Consultar");
		btnConsultar.setIcon(new ImageIcon(new ImageIcon(this.getClass().getResource("/icones/job-search__1_-removebg-preview.png")).getImage().getScaledInstance(24, 24, Image.SCALE_DEFAULT)));
		add(btnConsultar, "cell 0 16,growx");
		
		btnAtualizar = new JButton("Atualizar");
		btnAtualizar.setIcon(new ImageIcon(new ImageIcon(this.getClass().getResource("/icones/update-removebg-preview.png")).getImage().getScaledInstance(24, 24, Image.SCALE_DEFAULT)));
		add(btnAtualizar, "cell 0 16,growx");
		
		btnRemover = new JButton("Remover");
		btnRemover.setIcon(new ImageIcon(new ImageIcon(this.getClass().getResource("/icones/remover-usuario-removebg-preview.png")).getImage().getScaledInstance(24, 24, Image.SCALE_DEFAULT)));
		add(btnRemover, "cell 0 16,growx");
		
		btnLimpar = new JButton("Limpar");
		btnLimpar.setIcon(new ImageIcon(new ImageIcon(this.getClass().getResource("/icones/icons8-erase-40__1_-removebg-preview.png")).getImage().getScaledInstance(24, 24, Image.SCALE_DEFAULT)));
		add(btnLimpar, "cell 0 16,growx");
		
		JLabel lblNewLabel_13 = new JLabel("Representante da Universidade");
		add(lblNewLabel_13, "cell 0 12,growx");

	}

	public JTextField getTextFieldCodigo() {
		return textFieldCodigo;
	}

	public void setTextFieldCodigo(JTextField textFieldCodigo) {
		this.textFieldCodigo = textFieldCodigo;
	}

	public JTextField getTextFieldNomeCurso() {
		return textFieldNomeCurso;
	}

	public void setTextFieldNomeCurso(JTextField textFieldNomeCurso) {
		this.textFieldNomeCurso = textFieldNomeCurso;
	}

	public JTextField getTextFieldCargoRepCurso() {
		return textFieldCargoRepCurso;
	}

	public void setTextFieldCargoRepCurso(JTextField textFieldCargoRepCurso) {
		this.textFieldCargoRepCurso = textFieldCargoRepCurso;
	}

	public JTextField getTextFieldNomeUni() {
		return textFieldNomeUni;
	}

	public void setTextFieldNomeUni(JTextField textFieldNomeUni) {
		this.textFieldNomeUni = textFieldNomeUni;
	}

	public JTextField getTextFieldRepCoord() {
		return textFieldRepCoord;
	}

	public void setTextFieldRepCoord(JTextField textFieldRepCoord) {
		this.textFieldRepCoord = textFieldRepCoord;
	}

	public JTextField getTextFieldCnpj() {
		return textFieldCnpj;
	}

	public void setTextFieldCnpj(JTextField textFieldCnpj) {
		this.textFieldCnpj = textFieldCnpj;
	}

	public JTextField getTextFieldCep() {
		return textFieldCep;
	}

	public void setTextFieldCep(JTextField textFieldCep) {
		this.textFieldCep = textFieldCep;
	}

	public JTextField getTextFieldEndereco() {
		return textFieldEndereco;
	}

	public void setTextFieldEndereco(JTextField textFieldEndereco) {
		this.textFieldEndereco = textFieldEndereco;
	}

	public JTextField getTextFieldBairro() {
		return textFieldBairro;
	}

	public void setTextFieldBairro(JTextField textFieldBairro) {
		this.textFieldBairro = textFieldBairro;
	}

	public JTextField getTextFieldCidade() {
		return textFieldCidade;
	}

	public void setTextFieldCidade(JTextField textFieldCidade) {
		this.textFieldCidade = textFieldCidade;
	}

	public JTextField getTextFieldEstado() {
		return textFieldEstado;
	}

	public void setTextFieldEstado(JTextField textFieldEstado) {
		this.textFieldEstado = textFieldEstado;
	}

	public JTextField getTextFieldRepUniv() {
		return textFieldRepUniv;
	}

	public void setTextFieldRepUniv(JTextField textFieldRepUniv) {
		this.textFieldRepUniv = textFieldRepUniv;
	}

	public JTextField getTextFieldTelefoneUniv() {
		return textFieldTelefoneUniv;
	}

	public void setTextFieldTelefoneUniv(JTextField textFieldTelefoneUniv) {
		this.textFieldTelefoneUniv = textFieldTelefoneUniv;
	}

	public JTextField getTextFieldCargoRepUniv() {
		return textFieldCargoRepUniv;
	}

	public void setTextFieldCargoRepUniv(JTextField textFieldCargoRepUniv) {
		this.textFieldCargoRepUniv = textFieldCargoRepUniv;
	}

	public JTextField getTextFieldTelefoneCoord() {
		return textFieldTelefoneCoord;
	}

	public void setTextFieldTelefoneCoord(JTextField textFieldTelefoneCoord) {
		this.textFieldTelefoneCoord = textFieldTelefoneCoord;
	}

	public JButton getBtnCriar() {
		return btnCriar;
	}

	public void setBtnCriar(JButton btnCriar) {
		this.btnCriar = btnCriar;
	}

	public JButton getBtnConsultar() {
		return btnConsultar;
	}

	public void setBtnConsultar(JButton btnConsultar) {
		this.btnConsultar = btnConsultar;
	}

	public JButton getBtnAtualizar() {
		return btnAtualizar;
	}

	public void setBtnAtualizar(JButton btnAtualizar) {
		this.btnAtualizar = btnAtualizar;
	}

	public JButton getBtnRemover() {
		return btnRemover;
	}

	public void setBtnRemover(JButton btnRemover) {
		this.btnRemover = btnRemover;
	}

	public JButton getBtnLimpar() {
		return btnLimpar;
	}

	public void setBtnLimpar(JButton btnLimpar) {
		this.btnLimpar = btnLimpar;
	}

	
}
