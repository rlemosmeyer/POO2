package visao;

import javax.swing.JPanel;
import net.miginfocom.swing.MigLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JRadioButton;

import java.awt.Image;
import java.net.URL;
import java.text.ParseException;

import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JTextPane;
import javax.swing.text.MaskFormatter;
import javax.swing.ImageIcon;

public class TelaTermo extends JPanel {
	private JFormattedTextField textFieldInicio;
	private JFormattedTextField textFieldFim;
	private JFormattedTextField textFieldHoraInicio;
	private JFormattedTextField textFieldHoraFim;
	private JFormattedTextField textFieldChSemanal;
	private JTextField textFieldArea;
	private JFormattedTextField textFieldValorBolsa;
	private JTextField textFieldBeneficios;
	private JFormattedTextField textFieldCpf;
	private JTextField textFieldNomeAluno;
	private JTextField textFieldOrientador;
	private JTextField textFieldCurso;
	private JTextField textFieldUniversidade;
	private JFormattedTextField textFieldChDiaria;
	private JTextField textFieldRepresentUniv;
	private JTextField textFieldCnpj;
	private JTextField textFieldRazaoSocial;
	private JTextField textFieldNomeEmpresa;
	private JTextPane textPaneInfosComp;
	private JTextPane textPanePrincipais;
	private JButton btnCriar;
	private JButton btnConsultar;
	private JButton btnAtualizar;
	private JButton btnRemover;
	private JButton btnLimpar;

	/**
	 * Create the panel.
	 */
	public TelaTermo() {
		
		MaskFormatter maskData = null;
		try {
			maskData = new MaskFormatter("##/##/####");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		MaskFormatter maskHora = null;;
		try {
			maskHora = new MaskFormatter("##:##");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		MaskFormatter maskCh = null;;
		try {
			maskCh = new MaskFormatter("##");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		MaskFormatter maskCpf = null;;
		try {
			maskCpf = new MaskFormatter("###.###.###-##");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		MaskFormatter maskValor = null;;
		try {
			maskValor = new MaskFormatter("######");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		
		setLayout(new MigLayout("", "[grow]", "[][][][][][][][][][grow][][][][][][][][][][][][][][grow][]"));
		
		JLabel lblNewLabel = new JLabel("In\u00EDcio do Est\u00E1gio");
		add(lblNewLabel, "flowx,cell 0 0,growx");
		
		textFieldInicio = new JFormattedTextField(maskData);
		add(textFieldInicio, "flowx,cell 0 1,growx");
		textFieldInicio.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("CH Di\u00E1ria");
		add(lblNewLabel_2, "flowx,cell 0 2,growx");
		
		JLabel lblNewLabel_4 = new JLabel("Hora Início");
		add(lblNewLabel_4, "flowx,cell 0 4,growx");
		
		textFieldHoraInicio = new JFormattedTextField(maskHora);
		add(textFieldHoraInicio, "flowx,cell 0 5,growx");
		textFieldHoraInicio.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Fim do Est\u00E1gio");
		add(lblNewLabel_1, "cell 0 0,growx");
		
		textFieldFim = new JFormattedTextField(maskData);
		add(textFieldFim, "cell 0 1,growx");
		textFieldFim.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("CH Semanal");
		add(lblNewLabel_3, "cell 0 2,growx");
		
		textFieldChDiaria = new JFormattedTextField(maskCh);
		add(textFieldChDiaria, "flowx,cell 0 3,growx");
		textFieldChDiaria.setColumns(10);
		
		textFieldChSemanal = new JFormattedTextField(maskCh);
		add(textFieldChSemanal, "cell 0 3,growx");
		textFieldChSemanal.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("Hora Fim");
		add(lblNewLabel_5, "cell 0 4,growx");
		
		textFieldHoraFim = new JFormattedTextField(maskHora);
		add(textFieldHoraFim, "cell 0 5,growx");
		textFieldHoraFim.setColumns(10);
		
		JLabel lblNewLabel_6 = new JLabel("Área Estágio");
		add(lblNewLabel_6, "flowx,cell 0 6,growx");
		
		textFieldArea = new JTextField();
		add(textFieldArea, "flowx,cell 0 7,growx");
		textFieldArea.setColumns(10);
		
		JLabel lblNewLabel_7 = new JLabel("Principais Atividades");
		add(lblNewLabel_7, "cell 0 8");
		
		textPanePrincipais = new JTextPane();
		add(textPanePrincipais, "cell 0 9,grow");
		
		JLabel lblNewLabel_8 = new JLabel("Valor da Bolsa");
		add(lblNewLabel_8, "flowx,cell 0 10,growx");
		
		textFieldValorBolsa = new JFormattedTextField();
		add(textFieldValorBolsa, "flowx,cell 0 11,growx");
		textFieldValorBolsa.setColumns(10);
		
		JLabel lblNewLabel_9 = new JLabel("Benef\u00EDcios");
		add(lblNewLabel_9, "cell 0 10,growx");
		
		JLabel lblNewLabel_10 = new JLabel("CPF do Aluno");
		add(lblNewLabel_10, "flowx,cell 0 12,growx");
		
		JLabel lblNewLabel_11 = new JLabel("Nome do Aluno");
		add(lblNewLabel_11, "cell 0 12,growx");
		
		textFieldBeneficios = new JTextField();
		add(textFieldBeneficios, "cell 0 11,growx");
		textFieldBeneficios.setColumns(10);
		
		textFieldCpf = new JFormattedTextField(maskCpf);
		add(textFieldCpf, "flowx,cell 0 13,growx");
		textFieldCpf.setColumns(10);
		
		textFieldNomeAluno = new JTextField();
		textFieldNomeAluno.setEditable(false);
		add(textFieldNomeAluno, "cell 0 13,growx");
		textFieldNomeAluno.setColumns(10);
		
		JLabel lblNewLabel_12 = new JLabel("Curso");
		add(lblNewLabel_12, "flowx,cell 0 14,growx");
		
		textFieldCurso = new JTextField();
		textFieldCurso.setEditable(false);
		add(textFieldCurso, "cell 0 15,growx");
		textFieldCurso.setColumns(10);
		
		textFieldOrientador = new JTextField();
		textFieldOrientador.setEditable(false);
		add(textFieldOrientador, "cell 0 15,growx");
		textFieldOrientador.setColumns(10);
		
		JLabel lblNewLabel_14 = new JLabel("Universidade");
		add(lblNewLabel_14, "flowx,cell 0 16,growx");
		
		textFieldUniversidade = new JTextField();
		textFieldUniversidade.setEditable(false);
		add(textFieldUniversidade, "flowx,cell 0 17,growx");
		textFieldUniversidade.setColumns(10);
		
		JLabel lblNewLabel_16 = new JLabel("CNPJ da Empresa Concedente");
		add(lblNewLabel_16, "flowx,cell 0 18,growx");
		
		textFieldCnpj = new JTextField();
		add(textFieldCnpj, "flowx,cell 0 19,growx");
		textFieldCnpj.setColumns(10);
		
		JLabel lblNewLabel_18 = new JLabel("Nome do Representante da Empresa Concedente");
		lblNewLabel_18.setToolTipText("Da empresa concedente");
		add(lblNewLabel_18, "cell 0 20,growx");
		
		textFieldNomeEmpresa = new JTextField();
		textFieldNomeEmpresa.setEditable(false);
		add(textFieldNomeEmpresa, "cell 0 21,growx");
		textFieldNomeEmpresa.setColumns(10);
		
		JLabel lblNewLabel_19 = new JLabel("Informa\u00E7\u00F5es Complementares sobre o Est\u00E1gio");
		add(lblNewLabel_19, "cell 0 22");
		
		textPaneInfosComp = new JTextPane();
		add(textPaneInfosComp, "cell 0 23,grow");
		
		btnCriar = new JButton("Criar");
		btnCriar.setIcon(new ImageIcon(new ImageIcon(this.getClass().getResource("/icones/icons8-plus-+-40.png")).getImage().getScaledInstance(24, 24, Image.SCALE_DEFAULT)));
		add(btnCriar, "flowx,cell 0 24,growx");
		
		btnConsultar = new JButton("Consultar");
		btnConsultar.setIcon(new ImageIcon(new ImageIcon(this.getClass().getResource("/icones/job-search__1_-removebg-preview.png")).getImage().getScaledInstance(24, 24, Image.SCALE_DEFAULT)));
		add(btnConsultar, "cell 0 24,growx");
		
		ImageIcon imageIcon = new ImageIcon(new ImageIcon(this.getClass().getResource("/icones/update-removebg-preview.png")).getImage().getScaledInstance(24, 24, Image.SCALE_DEFAULT));
		btnAtualizar = new JButton("Atualizar");
		btnAtualizar.setIcon(imageIcon);
		add(btnAtualizar, "cell 0 24,growx");
		
		ImageIcon imageIconRm = new ImageIcon(new ImageIcon(this.getClass().getResource("/icones/remover-usuario-removebg-preview.png")).getImage().getScaledInstance(24, 24, Image.SCALE_DEFAULT));
		btnRemover = new JButton("Remover");
		btnRemover.setIcon(imageIconRm);
		add(btnRemover, "cell 0 24,growx");
		
		
		btnLimpar = new JButton("Limpar");
		btnLimpar.setIcon(new ImageIcon(new ImageIcon(this.getClass().getResource("/icones/icons8-erase-40__1_-removebg-preview.png")).getImage().getScaledInstance(24, 24, Image.SCALE_DEFAULT)));
		add(btnLimpar, "cell 0 24,growx");
		
		JLabel lblNewLabel_13 = new JLabel("Orientador");
		add(lblNewLabel_13, "cell 0 14,growx");
		
		textFieldRepresentUniv = new JTextField();
		textFieldRepresentUniv.setEditable(false);
		add(textFieldRepresentUniv, "cell 0 17,growx");
		textFieldRepresentUniv.setColumns(10);
		
		JLabel lblNewLabel_15 = new JLabel("Representante da Univesidade");
		add(lblNewLabel_15, "cell 0 16,growx");
		
		JLabel lblNewLabel_17 = new JLabel("Raz\u00E3o Social da Empresa Concedente");
		add(lblNewLabel_17, "cell 0 18,growx");
		
		textFieldRazaoSocial = new JTextField();
		textFieldRazaoSocial.setEditable(false);
		add(textFieldRazaoSocial, "cell 0 19,growx");
		textFieldRazaoSocial.setColumns(10);

	}

	public JFormattedTextField getTextFieldInicio() {
		return textFieldInicio;
	}

	public void setTextFieldInicio(JFormattedTextField textFieldInicio) {
		this.textFieldInicio = textFieldInicio;
	}

	public JFormattedTextField getTextFieldFim() {
		return textFieldFim;
	}

	public void setTextFieldFim(JFormattedTextField textFieldFim) {
		this.textFieldFim = textFieldFim;
	}

	public JFormattedTextField getTextFieldHoraInicio() {
		return textFieldHoraInicio;
	}

	public void setTextFieldHoraInicio(JFormattedTextField textFieldHoraInicio) {
		this.textFieldHoraInicio = textFieldHoraInicio;
	}

	public JFormattedTextField getTextFieldHoraFim() {
		return textFieldHoraFim;
	}

	public void setTextFieldHoraFim(JFormattedTextField textFieldHoraFim) {
		this.textFieldHoraFim = textFieldHoraFim;
	}

	public JFormattedTextField getTextFieldChSemanal() {
		return textFieldChSemanal;
	}

	public void setTextFieldChSemanal(JFormattedTextField textFieldChSemanal) {
		this.textFieldChSemanal = textFieldChSemanal;
	}

	public JTextField getTextFieldArea() {
		return textFieldArea;
	}

	public void setTextFieldArea(JTextField textFieldArea) {
		this.textFieldArea = textFieldArea;
	}

	public JFormattedTextField getTextFieldValorBolsa() {
		return textFieldValorBolsa;
	}

	public void setTextFieldValorBolsa(JFormattedTextField textFieldValorBolsa) {
		this.textFieldValorBolsa = textFieldValorBolsa;
	}

	public JTextField getTextFieldBeneficios() {
		return textFieldBeneficios;
	}

	public void setTextFieldBeneficios(JTextField textFieldBeneficios) {
		this.textFieldBeneficios = textFieldBeneficios;
	}

	public JFormattedTextField getTextFieldCpf() {
		return textFieldCpf;
	}

	public void setTextFieldCpf(JFormattedTextField textFieldCpf) {
		this.textFieldCpf = textFieldCpf;
	}

	public JTextField getTextFieldNomeAluno() {
		return textFieldNomeAluno;
	}

	public void setTextFieldNomeAluno(JTextField textFieldNomeAluno) {
		this.textFieldNomeAluno = textFieldNomeAluno;
	}

	public JTextField getTextFieldOrientador() {
		return textFieldOrientador;
	}

	public void setTextFieldOrientador(JTextField textFieldOrientador) {
		this.textFieldOrientador = textFieldOrientador;
	}

	public JTextField getTextFieldCurso() {
		return textFieldCurso;
	}

	public void setTextFieldCurso(JTextField textFieldCurso) {
		this.textFieldCurso = textFieldCurso;
	}

	public JTextField getTextFieldUniversidade() {
		return textFieldUniversidade;
	}

	public void setTextFieldUniversidade(JTextField textFieldUniversidade) {
		this.textFieldUniversidade = textFieldUniversidade;
	}

	public JFormattedTextField getTextFieldChDiaria() {
		return textFieldChDiaria;
	}

	public void setTextFieldChDiaria(JFormattedTextField textFieldChDiaria) {
		this.textFieldChDiaria = textFieldChDiaria;
	}

	public JTextField getTextFieldRepresentUniv() {
		return textFieldRepresentUniv;
	}

	public void setTextFieldRepresentUniv(JTextField textFieldRepresentUniv) {
		this.textFieldRepresentUniv = textFieldRepresentUniv;
	}

	public JTextField getTextFieldCnpj() {
		return textFieldCnpj;
	}

	public void setTextFieldCnpj(JTextField textFieldCnpj) {
		this.textFieldCnpj = textFieldCnpj;
	}

	public JTextField getTextFieldRazaoSocial() {
		return textFieldRazaoSocial;
	}

	public void setTextFieldRazaoSocial(JTextField textFieldRazaoSocial) {
		this.textFieldRazaoSocial = textFieldRazaoSocial;
	}

	public JTextField getTextFieldNomeEmpresa() {
		return textFieldNomeEmpresa;
	}

	public void setTextFieldNomeEmpresa(JTextField textFieldNomeEmpresa) {
		this.textFieldNomeEmpresa = textFieldNomeEmpresa;
	}

	public JButton getBtnCriar() {
		return btnCriar;
	}

	public void setBtnCriar(JButton btnCriar) {
		this.btnCriar = btnCriar;
	}

	public JButton getBtnConsultar() {
		return btnConsultar;
	}

	public void setBtnConsultar(JButton btnConsultar) {
		this.btnConsultar = btnConsultar;
	}

	public JButton getBtnAtualizar() {
		return btnAtualizar;
	}

	public void setBtnAtualizar(JButton btnAtualizar) {
		this.btnAtualizar = btnAtualizar;
	}

	public JButton getBtnRemover() {
		return btnRemover;
	}

	public void setBtnRemover(JButton btnRemover) {
		this.btnRemover = btnRemover;
	}

	public JButton getBtnLimpar() {
		return btnLimpar;
	}

	public void setBtnLimpar(JButton btnLimpar) {
		this.btnLimpar = btnLimpar;
	}

	public JTextPane getTextPaneInfosComp() {
		return textPaneInfosComp;
	}

	public void setTextPaneInfosComp(JTextPane textPaneInfosComp) {
		this.textPaneInfosComp = textPaneInfosComp;
	}

	public JTextPane getTextPanePrincipais() {
		return textPanePrincipais;
	}

	public void setTextPanePrincipais(JTextPane textPanePrincipais) {
		this.textPanePrincipais = textPanePrincipais;
	}
	
	
	

}
