package visao;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.CardLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class TelaInicial extends JFrame {

	private JPanel contentPane;
	private JMenuBar menuBar;
	private JMenu mnLogon;
	private JMenuItem mntmAutenticar;
	private JMenuItem mntmSair;
	private JMenu mnGerenciar;
	private JMenuItem mntmEstagiario;
	private JMenuItem mntmCurso;
	private JMenuItem mntmConcedente;
	private JMenuItem mntmTermos;
	private CardLayout card;
	
	
	

	
	
	public TelaInicial() {
		setTitle("Termos de Compromissos de Est\u00E1gios n\u00E3o obrigat\u00F3rios");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 526, 375);
		setSize(1000, 1000);
		menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		mnLogon = new JMenu("Logon");
		menuBar.add(mnLogon);
		
		mntmAutenticar = new JMenuItem("Autenticar");
		mntmAutenticar.setIcon(new ImageIcon(TelaInicial.class.getResource("/icones/enter.png")));
		mnLogon.add(mntmAutenticar);
		
		mntmSair = new JMenuItem("Sair");
		mntmSair.setIcon(new ImageIcon(TelaInicial.class.getResource("/icones/logout.png")));
		mnLogon.add(mntmSair);
		
		mnGerenciar = new JMenu("Gerenciar");
		menuBar.add(mnGerenciar);
		
		mntmEstagiario = new JMenuItem("Estagi\u00E1rio");
		mntmEstagiario.setIcon(new ImageIcon(TelaInicial.class.getResource("/icones/working-man.png")));
		mntmEstagiario.setEnabled(false);
		mnGerenciar.add(mntmEstagiario);
		
		mntmCurso = new JMenuItem("Curso");
		mntmCurso.setIcon(new ImageIcon(TelaInicial.class.getResource("/icones/online-course.png")));
		mntmCurso.setEnabled(false);
		mnGerenciar.add(mntmCurso);
		
		mntmConcedente = new JMenuItem("Concedente");
		mntmConcedente.setIcon(new ImageIcon(TelaInicial.class.getResource("/icones/companhia.png")));
		mntmConcedente.setEnabled(false);
		mnGerenciar.add(mntmConcedente);
		
		mntmTermos = new JMenuItem("Termos de Compromisso");
		mntmTermos.setIcon(new ImageIcon(TelaInicial.class.getResource("/icones/termos-e-condicoes.png")));
		mntmTermos.setEnabled(false);
		mnGerenciar.add(mntmTermos);
		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		card = new CardLayout(0, 0);
		contentPane.setLayout(card);
	}

	public JMenu getMnLogon() {
		return mnLogon;
	}



	public void setMnLogon(JMenu mnLogon) {
		this.mnLogon = mnLogon;
	}



	public JMenuItem getMntmAutenticar() {
		return mntmAutenticar;
	}



	public void setMntmAutenticar(JMenuItem mntmAutenticar) {
		this.mntmAutenticar = mntmAutenticar;
	}



	public JMenuItem getMntmSair() {
		return mntmSair;
	}



	public void setMntmSair(JMenuItem mntmSair) {
		this.mntmSair = mntmSair;
	}



	public JMenu getMnGerenciar() {
		return mnGerenciar;
	}



	public void setMnGerenciar(JMenu mnGerenciar) {
		this.mnGerenciar = mnGerenciar;
	}



	public JMenuItem getMntmEstagiario() {
		return mntmEstagiario;
	}



	public void setMntmEstagiario(JMenuItem mntmEstagiario) {
		this.mntmEstagiario = mntmEstagiario;
	}



	public JMenuItem getMntmCurso() {
		return mntmCurso;
	}



	public void setMntmCurso(JMenuItem mntmCurso) {
		this.mntmCurso = mntmCurso;
	}



	public JMenuItem getMntmConcedente() {
		return mntmConcedente;
	}



	public void setMntmConcedente(JMenuItem mntmConcedente) {
		this.mntmConcedente = mntmConcedente;
	}



	public JMenuItem getMntmTermos() {
		return mntmTermos;
	}



	public void setMntmTermos(JMenuItem mntmTermos) {
		this.mntmTermos = mntmTermos;
	}



	public CardLayout getCard() {
		return card;
	}



	public void setCard(CardLayout card) {
		this.card = card;
	}

}
