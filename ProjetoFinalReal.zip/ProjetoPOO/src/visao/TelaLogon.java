package visao;

import javax.swing.JPanel;
import javax.swing.JLabel;
import net.miginfocom.swing.MigLayout;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.ImageIcon;

public class TelaLogon extends JPanel {
	
	private JTextField textField;
	private JPasswordField passwordField;
	private JButton btnEntrar;
	private JButton btnLimpar;
	private JLabel lblNewLabel_2;
	
	public TelaLogon() {
		setLayout(new MigLayout("", "[][][][][][][][][grow]", "[][][][][][][][][][]"));
		
		lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon(TelaLogon.class.getResource("/icones/login.png")));
		add(lblNewLabel_2, "cell 0 1 9 1,alignx center");
		
		JLabel lblNewLabel = new JLabel("Usu\u00E1rio");
		add(lblNewLabel, "cell 0 3");
		
		textField = new JTextField();
		add(textField, "cell 0 4 9 1,growx");
		textField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Senha");
		add(lblNewLabel_1, "cell 0 5");
		
		passwordField = new JPasswordField();
		add(passwordField, "cell 0 6 9 1,growx");
		
		btnLimpar = new JButton("Limpar");
		btnLimpar.setIcon(new ImageIcon(TelaLogon.class.getResource("/icones/broom.png")));
		add(btnLimpar, "cell 0 9,alignx trailing");
		
		btnEntrar = new JButton("Entrar");
		btnEntrar.setIcon(new ImageIcon(TelaLogon.class.getResource("/icones/user.png")));
		add(btnEntrar, "cell 1 9 8 1,growx");

	}

	public JTextField getTextField() {
		return textField;
	}

	public void setTextField(JTextField textField) {
		this.textField = textField;
	}

	public JPasswordField getPasswordField() {
		return passwordField;
	}

	public void setPasswordField(JPasswordField passwordField) {
		this.passwordField = passwordField;
	}

	public JButton getBtnEntrar() {
		return btnEntrar;
	}

	public void setBtnEntrar(JButton btnEntrar) {
		this.btnEntrar = btnEntrar;
	}

	public JButton getBtnLimpar() {
		return btnLimpar;
	}

	public void setBtnLimpar(JButton btnLimpar) {
		this.btnLimpar = btnLimpar;
	}
	
	

}
