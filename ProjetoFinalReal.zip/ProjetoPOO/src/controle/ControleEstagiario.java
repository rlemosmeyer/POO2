package controle;

import visao.TelaEstagiario;

public class ControleEstagiario {
	
	private TelaEstagiario te;
	
	public ControleEstagiario(TelaEstagiario te) {
		super();
		this.te = te;
		
	}
	
	

}
