package controle;

import visao.TelaInicial;

public class App {
	
	
	public static void main(String[] args) {
		
		TelaInicial ti = new TelaInicial();

		ti.setVisible(true);
		
		ControlePrincipal controle = new ControlePrincipal(ti);
	}
	
}
