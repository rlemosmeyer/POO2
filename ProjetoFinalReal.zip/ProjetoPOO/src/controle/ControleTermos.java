package controle;

import java.awt.Component;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.SwingUtilities;
import javax.swing.ImageIcon;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import dao.TermoDAO;
import modelo.Termo;
import visao.TelaTermo;

public class ControleTermos implements ActionListener {

	private TelaTermo tt;
	private Termo t;
	private TermoDAO tdao;

	public ControleTermos(TelaTermo tt) {
		super();
		this.tt = tt;
		
		this.tt.getBtnAtualizar().addActionListener(this);
		this.tt.getBtnConsultar().addActionListener(this);
		this.tt.getBtnCriar().addActionListener(this);
		this.tt.getBtnLimpar().addActionListener(this);
		this.tt.getBtnRemover().addActionListener(this);
		this.tt.getTextFieldCnpj().addActionListener(this);
		this.tt.getTextFieldCpf().addActionListener(this);
		
		this.tdao = new TermoDAO();
	}
	
	public static void cleanJTextFields(Component[] components) {
		for (Component c : components) {
			if (c instanceof JTextField) {
				((JTextField) c).setText("");
			}
			if (c instanceof JFormattedTextField) {
				((JFormattedTextField) c).setValue(null);
			}
			if (c instanceof JTextPane) {
				((JTextPane) c).setText("");
			}
		}
	}
	
	public static boolean verificaCampos(Component[] components) {
		for (Component c : components) {
			if (c instanceof JTextField) {
				if(((JTextField) c).getText() == "") {
					return false;
				}
			}
			if (c instanceof JTextPane) {
				if(((JTextPane) c).getText() == "") {
					return false;
				}
			}
		}
		return true;
	}


	@Override
	public void actionPerformed(ActionEvent e) {

		if(e.getActionCommand().equals("Limpar")) {
			this.tt.getTextFieldCpf().setEditable(true);
			this.tt.getTextFieldCnpj().setEditable(true);
			cleanJTextFields(tt.getComponents());
		}
		
		if(e.getActionCommand().equals("Remover")) {

		}
		
		if(e.getActionCommand().equals("Atualizar")) {

		}
		
		if(e.getActionCommand().equals("Criar")) {
			if(verificaCampos(this.tt.getComponents()) == false) {
				JOptionPane.showMessageDialog(tt, "Algum campo não foi preenchido. Lembre-se, todos são necessários.");
			}
			else {
				try {
					int chDiaria = Integer.parseInt(this.tt.getTextFieldChDiaria().getText());
					int chSemanal = Integer.parseInt(this.tt.getTextFieldChSemanal().getText());
					
					if(chDiaria <= 6) {
						if(chSemanal <= 30) {
							t = new Termo(0, this.tt.getTextFieldInicio().getText(), this.tt.getTextFieldFim().getText(), this.tt.getTextFieldChDiaria().getText(), this.tt.getTextFieldChSemanal().getText(), this.tt.getTextFieldArea().getText(), this.tt.getTextFieldHoraInicio().getText(), this.tt.getTextFieldHoraFim().getText(), this.tt.getTextPanePrincipais().getText(), this.tt.getTextFieldValorBolsa().getText(), this.tt.getTextFieldBeneficios().getText(), this.tt.getTextFieldCnpj().getText(), this.tt.getTextFieldCpf().getText(), this.tt.getTextFieldNomeAluno().getText(), this.tt.getTextFieldCurso().getText(), this.tt.getTextFieldOrientador().getText(), this.tt.getTextFieldUniversidade().getText(), this.tt.getTextFieldRepresentUniv().getText(), this.tt.getTextFieldRazaoSocial().getText(), this.tt.getTextFieldNomeEmpresa().getText(), this.tt.getTextPaneInfosComp().getText());
							if(tdao.salvaTermo(t) == true) {
								JOptionPane.showMessageDialog(tt, "Registro salvo no banco de dados!");
								cleanJTextFields(tt.getComponents());
							} else {
								JOptionPane.showMessageDialog(tt, "Ocorreu um erro ao inserir os registros no banco de dados.");
							}
						} else {
							JOptionPane.showMessageDialog(tt, "Carga horária semanal maior que 30h.");
						}
					} else {
						JOptionPane.showMessageDialog(tt, "Carga horária diária maior que 6h.");
					}
				} catch (Exception exc1) {
					JOptionPane.showMessageDialog(tt, "Ocorreu algum erro inesperado!");
				}
			}
			
		}
		
		if(e.getActionCommand().equals("Consultar")) {
			String id = JOptionPane.showInputDialog("Digite o ID do termo a ser consultado: ");
			if(id!= null) {
				try {
					int idNumero = Integer.parseInt(id);
					if(tdao.verificaTermo(idNumero) == true) {
						Termo t = tdao.consultaTermo(idNumero);
						this.tt.getTextFieldInicio().setText(t.getInicioEstagio());
						this.tt.getTextFieldFim().setText(t.getFimEstagio());
						this.tt.getTextFieldChDiaria().setText(t.getChDiaria());
						this.tt.getTextFieldChSemanal().setText(t.getChSemanal());
						this.tt.getTextFieldHoraInicio().setText(t.getHoraInicio());
						this.tt.getTextFieldHoraFim().setText(t.getHoraFim());
						this.tt.getTextFieldArea().setText(t.getAreaEstagio());
						this.tt.getTextPanePrincipais().setText(t.getPrincipaisAtividades());
						this.tt.getTextFieldValorBolsa().setText(t.getValorBolsa());
						this.tt.getTextFieldBeneficios().setText(t.getBeneficios());
						this.tt.getTextFieldCpf().setText(t.getCpf());
						this.tt.getTextFieldNomeAluno().setText(t.getNomeAluno());
						this.tt.getTextFieldCurso().setText(t.getCurso());
						this.tt.getTextFieldOrientador().setText(t.getOrientador());
						this.tt.getTextFieldUniversidade().setText(t.getUniversidade());
						this.tt.getTextFieldRepresentUniv().setText(t.getRepresentanteUniversidade());
						this.tt.getTextFieldCnpj().setText(t.getCnpj());
						this.tt.getTextFieldRazaoSocial().setText(t.getRazaoSocial());
						this.tt.getTextFieldNomeEmpresa().setText(t.getRepresentanteEmpresa());
						this.tt.getTextPaneInfosComp().setText(t.getInfosComplementares());
					} else {
						JOptionPane.showMessageDialog(tt, "Nenhum termo encontrado.");
					}
				} catch (Exception exc) {
					JOptionPane.showMessageDialog(tt, "Por favor, insira apenas o valor numérico referente ao ID do termo.");
				}
			}
		}
		
		if(e.getSource() == this.tt.getTextFieldCpf()) {
			if(tdao.validaCpf(this.tt.getTextFieldCpf().getText()) == true){
				String vet[] = new String[5];
				vet = tdao.retornaEstagiario(this.tt.getTextFieldCpf().getText());
				this.tt.getTextFieldNomeAluno().setText(vet[0]);
				this.tt.getTextFieldCurso().setText(vet[1]);
				this.tt.getTextFieldOrientador().setText(vet[2]);
				this.tt.getTextFieldUniversidade().setText(vet[3]);
				this.tt.getTextFieldRepresentUniv().setText(vet[4]);
				this.tt.getTextFieldCpf().setEditable(false);
			} else {
				ImageIcon icon = new ImageIcon(new ImageIcon(this.getClass().getResource("/icones/not-found.png")).getImage().getScaledInstance(128, 128, Image.SCALE_DEFAULT));
				JOptionPane.showConfirmDialog(null, "Não foi possível recuperar o CPF no banco de dados.", "CPF inválido",JOptionPane.DEFAULT_OPTION,JOptionPane.WARNING_MESSAGE, icon);
			}
		}
		
		if(e.getSource() == this.tt.getTextFieldCnpj()) {
			if(tdao.validaCnpj(this.tt.getTextFieldCnpj().getText())){
				String vet[] = new String[2];
				vet = tdao.retornaEmpresa(this.tt.getTextFieldCnpj().getText());
				this.tt.getTextFieldNomeEmpresa().setText(vet[1]);
				this.tt.getTextFieldRazaoSocial().setText(vet[0]);
				this.tt.getTextFieldCnpj().setEditable(false);
			} else {
				ImageIcon icon = new ImageIcon(new ImageIcon(this.getClass().getResource("/icones/not-found.png")).getImage().getScaledInstance(128, 128, Image.SCALE_DEFAULT));
				JOptionPane.showConfirmDialog(null, "Não foi possível recuperar o CNPJ da empresa no banco de dados.", "CNPJ inválido",JOptionPane.DEFAULT_OPTION,JOptionPane.WARNING_MESSAGE, icon);
			}
		}
		
	}
	
	
}
