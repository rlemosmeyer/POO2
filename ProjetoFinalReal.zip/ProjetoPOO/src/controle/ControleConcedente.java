package controle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import visao.TelaConcedente;

public class ControleConcedente implements ActionListener{
	
	private TelaConcedente tc;

	public ControleConcedente(TelaConcedente tc) {
		super();
		this.tc = tc;
		
		
		this.tc.getBtnAtualizar().addActionListener(this);
		this.tc.getBtnConsultar().addActionListener(this);
		this.tc.getBtnCriar().addActionListener(this);
		this.tc.getBtnLimpar().addActionListener(this);
		this.tc.getBtnRemover().addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		
	}
	
	

}
