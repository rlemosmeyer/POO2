package controle;

import visao.TelaCurso;

public class ControleCurso {
	
	private TelaCurso tc;

	public ControleCurso(TelaCurso tc) {
		super();
		this.tc = tc;
	}
	
	

}
