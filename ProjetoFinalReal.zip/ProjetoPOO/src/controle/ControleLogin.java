package controle;

import java.awt.Component;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import dao.UsuarioDAO;
import modelo.Usuario;
import visao.TelaInicial;
import visao.TelaLogon;

public class ControleLogin implements ActionListener {
	
	private TelaLogon tl;
	private TelaInicial ti;
	private UsuarioDAO dao;
	private Usuario u;
	
	public ControleLogin(TelaLogon tl, TelaInicial ti) {
		super();
		this.tl = tl;
		this.ti = ti;
		
		this.tl.getBtnLimpar().addActionListener(this);
		this.tl.getBtnEntrar().addActionListener(this);
		
		this.dao = new UsuarioDAO();
	}

	public static void cleanJTextFields(Component[] components) {
		for (Component c : components) {
			if (c instanceof JTextField) {
				((JTextField) c).setText("");
			}
		}
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getActionCommand().equals("Limpar")) {
			cleanJTextFields(tl.getComponents());
		}
		if(e.getActionCommand().equals("Entrar")) {
			u = new Usuario(0, this.tl.getTextField().getText(), String.valueOf(this.tl.getPasswordField().getPassword()));
			if(dao.login(u)){
				this.ti.getMntmAutenticar().setEnabled(true);
				this.ti.getMntmConcedente().setEnabled(true);
				this.ti.getMntmCurso().setEnabled(true);
				this.ti.getMntmEstagiario().setEnabled(true);
				this.ti.getMntmTermos().setEnabled(true);
				ImageIcon icon = new ImageIcon(new ImageIcon(this.getClass().getResource("/icones/icons8-enter-48 (1).png")).getImage().getScaledInstance(128, 128, Image.SCALE_DEFAULT));
				JOptionPane.showConfirmDialog(null, "Login efetuado com sucesso!", "Autenticado", JOptionPane.DEFAULT_OPTION,JOptionPane.WARNING_MESSAGE,icon);
				cleanJTextFields(tl.getComponents());
			}
			else {
				ImageIcon icon = new ImageIcon(new ImageIcon(this.getClass().getResource("/icones/ad.png")).getImage().getScaledInstance(128, 128, Image.SCALE_DEFAULT));
				JOptionPane.showConfirmDialog(ti, "Nenhum usuário encontrado no banco de dados com estas credenciais", "Erro!", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE, icon);
			}
		}
		
	}
	
	

}
