package controle;

import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

import visao.TelaConcedente;
import visao.TelaCurso;
import visao.TelaEstagiario;
import visao.TelaInicial;
import visao.TelaLogon;
import visao.TelaTermo;

public class ControlePrincipal implements ActionListener {
	
	private TelaInicial ti;
	private TelaCurso telaCurso;
	private TelaEstagiario telaEstagiario;
	private TelaLogon telaLogon;
	private TelaTermo telaTermo;
	private TelaConcedente telaConcedente;
	
	
	

	public ControlePrincipal(TelaInicial ti) {
		super();
		this.ti = ti;
		
		this.telaCurso = new TelaCurso();
	    this.telaEstagiario = new TelaEstagiario();
		this.telaLogon = new TelaLogon();
		this.telaTermo = new TelaTermo();
		this.telaConcedente = new TelaConcedente();
		
		ControleLogin cl = new ControleLogin(telaLogon, ti);
				
		this.ti.getContentPane().add(telaConcedente, "t0");
		this.ti.getContentPane().add(telaTermo, "t1");
		this.ti.getContentPane().add(telaCurso, "t2");
		this.ti.getContentPane().add(telaEstagiario, "t3");
		this.ti.getContentPane().add(telaLogon, "t4");
		this.ti.getCard().show(ti.getContentPane(), "t4");
		this.ti.setSize(500,400);
		this.ti.setLocationRelativeTo(null);

		
		this.ti.getMntmSair().addActionListener(this);
		this.ti.getMnLogon().addActionListener(this);
		this.ti.getMntmAutenticar().addActionListener(this);
		this.ti.getMntmConcedente().addActionListener(this);
		this.ti.getMntmCurso().addActionListener(this);
		this.ti.getMntmEstagiario().addActionListener(this);
		this.ti.getMntmTermos().addActionListener(this);		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getActionCommand().equals("Sair")) {
			ImageIcon icon = new ImageIcon(new ImageIcon(this.getClass().getResource("/icones/logout_colorido.png")).getImage().getScaledInstance(128, 128, Image.SCALE_DEFAULT));
			int opcao = JOptionPane.showConfirmDialog(ti, "Você deseja mesmo sair?", "Sair", JOptionPane.YES_OPTION, JOptionPane.WARNING_MESSAGE, icon);
			if(opcao == JOptionPane.YES_OPTION) {
				System.exit(0);
			}
		}
		
		if(e.getActionCommand().equals("Curso")) {
			ControleCurso ccur = new ControleCurso(telaCurso);
			this.ti.getCard().show(ti.getContentPane(), "t2");
			this.ti.setSize(600,550);
			this.ti.setLocationRelativeTo(null);

		}
		
		if(e.getActionCommand().equals("Autenticar")) {
			ControleLogin cl = new ControleLogin(telaLogon, ti);
			this.ti.getCard().show(ti.getContentPane(), "t4");
			this.ti.setSize(600,400);
			this.ti.setLocationRelativeTo(null);

		}
		
		if(e.getActionCommand().equals("Concedente")) {
			ControleConcedente ccon = new ControleConcedente(telaConcedente);
			this.ti.getCard().show(ti.getContentPane(), "t0");
			this.ti.setSize(600,550);
			this.ti.setLocationRelativeTo(null);

		}
		
		if(e.getActionCommand().equals("Estagiário")) {
			ControleEstagiario ce = new ControleEstagiario(telaEstagiario);
			this.ti.getCard().show(ti.getContentPane(), "t3");
			this.ti.setSize(600,550);
			this.ti.setLocationRelativeTo(null);

		}
		
		if(e.getActionCommand().equals("Termos de Compromisso")) {
			ControleTermos ct = new ControleTermos(telaTermo);
			this.ti.getCard().show(ti.getContentPane(), "t1");
			this.ti.setSize(600,900);
			this.ti.setLocationRelativeTo(null);

		}
		
	}

}
